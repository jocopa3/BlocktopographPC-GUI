This program is in beta, so PLEASE BACK-UP YOUR WORLDS BEFORE USING IT.

This program is Licensed under the AGPL v3 license, a copy of which can
be found in the "LICENSE.txt" file. All other licenses for projects used
in this software can be found in the included "Licenses" folder.